package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class mainController {
    @FXML
    private TextField nameField;
    
    @FXML
    private Label resultLabel;

    @FXML
    private void handleButtonClick() {
        String name = nameField.getText();
        if (name.isEmpty()) {
            resultLabel.setText("Vui lòng nhập tên!");
        } else {
            resultLabel.setText("Chào, " + name + "!");
        }
    }
}
